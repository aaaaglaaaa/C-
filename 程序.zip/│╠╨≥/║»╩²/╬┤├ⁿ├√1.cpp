#define N 8
#include<stdio.h>
int main(void)
{
	int a[N];
	int i,j,temp;
	for(i=0;i<N;i++)
	scanf("%d",&a[i]);
	for (i=0;i<N/2;i++)
	{
		j=N-i-1;
		temp=a[j];
		a[j]=a[i];
		a[i]=temp;
	
	}
	for(i=0;i<N;i++)
	{printf("%d ",a[i]);
	}
	return 0;
}
