#include<stdio.h>
int change(int n)
{   int sum=0;
	while(n/10!=0)
	{
	sum=sum+(n%10);
	n=n/10;
		
	}
	sum+=n;
	return sum;
}
int main(void)
{
	int num,result;
	scanf("%d",&num);
	result=change(num);
	
	while(result>10)
	result=change(result);
	printf("%d",result);
	return 0;
}
