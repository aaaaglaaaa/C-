#include<stdio.h>
int main(void)//��һ�� 20009101907 
{
	void select_sort(int a[],int n);//��������
    int m;
	scanf("%d",&m);
	int num[m] ;
	for(int i=0;i<m;i++) scanf("%d",&num[i]);
    select_sort(num,m);
    for(int j=0;j<m;j++) printf("%d ",num[j]);
	return 0;
	
}
void select_sort(int a[],int n)
{   int temp; 
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
			
		}
	}
	
