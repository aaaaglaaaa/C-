#include <stdio.h>
int s(int n)
{if (n==1) 
return 0;

 else   for(int i=2;i<n;i++){
    
        if(n%i==0) return 0;
        else return 1;
        }}
    int main (void)
    {int num;
    scanf("%d",&num);
	
 if(s(num))
 printf("YES");
 else printf("NO");
 return 0; }

    
   
