#include<stdio.h>
double function(int n);
int main(void)
{
	int num;
	scanf("%d",&num);
	printf("%.6lf",function(num));
	return 0;
}
double function(int n)
{
	if(n==1)
	return 1.0;
	else
	return  1/(1+function(n-1));
}
