#include<stdio.h>
int main(void)
{
	int function(int a, int b);
	int num1,num2;
	scanf("%d",&num1);
	scanf("%d",&num2);
	printf("%d",function(num1,num2));
	 return 0; 
}
int function(int a, int b)
{
	int a1,b1,c,d;
	int num,i=0;
	for(num=a;num<=b;num++)
	{
		if(num>=100&&num<1000)
		{
			a1=num/100;
			b1=(num-a1*100)/10;
			c=(num-a1*100-b1*10);
			if(a1*a1*a1+b1*b1*b1+c*c*c==num)
			i++;
		}
		else if(num>1000&&num<10000);
		{
			a1=num/1000;
			b1=(num-a1*1000)/100;
			c=(num-a1*1000-b1*100)/10;
			d=(num-a1*1000-b1*100-c*10);
			if(a1*a1*a1*a1+b1*b1*b1*b1+c*c*c*c+d*d*d*d==num)
			i++;
		}
	}
	return i;
}


