#include <stdio.h>
int s(int n)
{if (n==1) 
return 0;

 else   for(int i=2;i<n;i++){
    
        if(n%i==0) return 0;
        else return 1;
        }}
int feibo(int n)
{
	if (n==1||n==2)
	return 1;
	else return feibo(n-1)+feibo(n-2);
}
int main(void){

int num;
scanf("%d",&num);
if(s(feibo(num)))
printf("YES");
else printf("%d",feibo(num));
return 0;}
