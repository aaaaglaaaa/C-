#include<stdio.h>
int main(void)
{
	void bubble(int a[],int n);
	int num;
	scanf("%d",&num); 
	int a[num];
	for(int i=0;i<num;i++)
	scanf("%d",&a[i]);
	bubble(a,num);
	for(int j=0;j<num;j++)
	printf("%d ",a[j]);
	return 0;
}
void bubble(int a[],int n)
{
	for(int i=n-1;i>=0;i--)
	{
		for(int j=0;j<i;j++)
		{
		if(a[j]>a[j+1]){
	
				int temp;
				temp=a[j];
			    a[j]=a[j+1];
			    a[j+1]=temp;	}
			    
			   
		}
	}
}
