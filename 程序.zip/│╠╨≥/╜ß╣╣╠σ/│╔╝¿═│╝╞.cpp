#include<stdio.h>
struct inf
{
	int num;
	char name[20];
	int g1;
	int g2;
	int g3;
	float aver;
};
int main(void)
{
	struct inf stu[101]={0,"\0",0,0,0,0.0},temp;
	int n,i,j;
	scanf("%d",&n);
	for(i=0;i<n;i++) 
	{
		scanf("%d %s %d %d %d",&stu[i].num,&stu[i].name,&stu[i].g1,&stu[i].g2,&stu[i].g3); 
		stu[i].aver=(stu[i].g1+stu[i].g2+stu[i].g3)/(3.0);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(stu[i].aver<stu[j].aver)
			{
				temp=stu[i];
				stu[i]=stu[j];
				stu[j]=temp;
			}
			else if(stu[i].aver==stu[j].aver)
			{
				if(stu[i].num<stu[j].num)
				{
					temp=stu[i];
				    stu[i]=stu[j];
				    stu[j]=temp;
				}
			}
		}
	}
	for(i=0;i<n;i++) printf("%d %s %.1f\n",stu[i].num,stu[i].name,stu[i].aver);
	return 0; 
}
