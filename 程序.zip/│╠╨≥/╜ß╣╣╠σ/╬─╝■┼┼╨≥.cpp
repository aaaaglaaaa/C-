#include<stdio.h>
struct inf
{
	int ye;
	int mou;
	int day;
	int bit;
};
int main(void)
{
	struct inf flie[100],temp;
	int n,i,j;
	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("%d/%d/%d %d",&flie[i].ye,&flie[i].mou,&flie[i].day,&flie[i].bit);
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(flie[i].ye<flie[j].ye)
			{
				temp=flie[i];
				flie[i]=flie[j];
				flie[j]=temp;
			}
			else if(flie[i].ye==flie[j].ye)
			{
				if(flie[i].mou<flie[j].mou)
				{
					temp=flie[i];
				    flie[i]=flie[j];
				    flie[j]=temp;
				}
				else if(flie[i].mou==flie[j].mou)
				{
					if(flie[i].day<flie[j].day)
					{
						temp=flie[i];
				        flie[i]=flie[j];
				        flie[j]=temp;
					}
					else if(flie[i].day==flie[j].day)
					{
						if(flie[i].bit<flie[j].bit)
						{
							temp=flie[i];
				            flie[i]=flie[j];
				            flie[j]=temp;
						}
					}
				}
			}
		}
	}
	printf("\n");
	for(i=0;i<n;i++) printf("%d/%d/%d %d\n",flie[i].ye,flie[i].mou,flie[i].day,flie[i].bit);
	return 0;
}
