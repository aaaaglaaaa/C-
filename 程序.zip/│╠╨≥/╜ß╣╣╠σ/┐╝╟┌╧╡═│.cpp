#include<stdio.h>
struct inf
{
	int num;
	int h1;
	int m1;
	int h2;
	int m2;
	int sum;
};
int main(void)
{
	struct inf stu[101]={0,0,0,0,0,0},temp;
	int n,i,j,x;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&x);
		stu[x].num=x;
		scanf("%d:%d %d:%d",&stu[x].h1,&stu[x].m1,&stu[x].h2,&stu[x].m2);
		stu[x].sum+=(stu[x].h2-stu[x].h1)*60+(stu[x].m2-stu[x].m1);
	}
	for(i=1;i<100;i++)
	{
		for(j=i+1;j<101;j++)
		{
			if(stu[i].sum<stu[j].sum)
			{
				temp=stu[j];
				stu[j]=stu[i];
				stu[i]=temp;
			}
		}
	}
	for(i=1;i<101,stu[i].num!=0;i++) printf("%d %d\n",stu[i].num,stu[i].sum);
	return 0;
}

