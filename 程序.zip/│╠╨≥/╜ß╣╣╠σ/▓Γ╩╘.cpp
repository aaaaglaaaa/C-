#include<stdio.h>
#define people 3
struct Student
{
	char name[20];
	float score;
};
int main(void)
{
	struct Student stu[people]={{"zhang",78.5},{"zhou",100},{"zhu",90}};
	struct Student temp;
	int i,j,k;
	printf("�ɼ��ǣ�\n");
	for(i=0;i<people-1;i++)
	{
		for(j=i+1;j<people;j++)
		{
			if(stu[j].score>stu[i].score)
			{
				temp=stu[j];
				stu[j]=stu[i];
				stu[i]=temp;
			}
		}
	}
	for(i=0;i<people;i++)
	printf("%8s %6.0f\n",stu[i].name,stu[i].score);
	return 0;
	
}
