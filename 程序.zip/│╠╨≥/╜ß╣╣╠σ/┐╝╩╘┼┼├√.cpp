#include<stdio.h>
int main()
{
	int n,i,j;
	struct Student
	{
		char name[20];
		int t1;
		int t2;
		int t3;
		int t4;
		int t5;
		int ex;
		int sum;
	}stu[100],temp;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
		scanf("%s %d %d %d %d %d %d", stu[i].name, &stu[i].t1, &stu[i].t2, &stu[i].t3, &stu[i].t4, &stu[i].t5, &stu[i].ex);
	for (i = 0; i < n; i++)
		stu[i].sum = stu[i].t1 + stu[i].t2 + stu[i].t3 + stu[i].t4 + stu[i].t5+stu[i].ex;
	for (i = 1; i < n; i++)
	{
		for (j = 0; j < n - 1; j++)
		{
			if (stu[j].ex < stu[j + 1].ex)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
	}
	for (i = 1; i < n; i++)
	{
		for (j = 0; j < n - 1; j++)
		{
			if (stu[j].sum < stu[j + 1].sum)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
	}
	for (i = 0; i < n; i++)
		printf("%s %d %d\n", stu[i].name, stu[i].sum, stu[i].ex);
}
