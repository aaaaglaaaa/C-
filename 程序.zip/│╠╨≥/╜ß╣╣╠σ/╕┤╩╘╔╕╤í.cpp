#include<stdio.h>
struct inf
{
	char num[20];
	int total;
	int english;
}; 
int main(void)
{
	int m,n,i,j;
	scanf("%d %d",&m,&n);
	struct inf stu[200];
	struct inf temp;
	for(i=0;i<m;i++)
	{
		scanf("%s %d %d",stu[i].num,&stu[i].total,&stu[i].english);
	}
	for(i=0;i<m-1;i++)
	{
		for(j=i+1;j<m;j++)
		{
			if(stu[i].total<stu[j].total)
			{
				temp=stu[i];
				stu[i]=stu[j];
				stu[j]=temp;
			}
			else if(stu[i].total==stu[j].total)
			{
				if(stu[i].english<stu[j].english)
				{
					temp=stu[i];
				    stu[i]=stu[j];
				    stu[j]=temp;
				}
			}
			else;
		}
	}
	printf("\n");
	for(i=0;i<n;i++)
	{
		printf("%s %d %d\n",stu[i].num,stu[i].total,stu[i].english);
		
	}
	return 0;
}
