#include<stdio.h>
#include<math.h>
int main()
{
	int function(int a,int b);
	int e,f,w;
	scanf("%d %d",&e,&f);
	w=function(e,f);
	printf("%d",w);
	return 0;
}
int function(int a,int b)
{
	int c[10000],m,n,sum,q=0,leap=0,t,i;
	if(a>b)
	{
		t=a;
		a=b;
		b=t;
	}
	if(b<=100)
	leap=0;
	if(a<100)
	a=100;     //��[a,b]ѡ��
	for(n=a;n<=b;n++)
	{
		m=n;
		for(i=0;i<100;i++)
		{if(m>0)
			{
			c[i]=m%10;
			m=m/10;
			q++;}
		}         //ȡ��n��ÿһλ��������c[i]�� 
		for(i=0,sum=0;i<q;i++)
		{
		   sum=sum+pow(c[i],q);	
		}
		if(sum==n)
		leap++;
		q=0;
		sum=0;
	 } 
	 return leap;
	
	
}

