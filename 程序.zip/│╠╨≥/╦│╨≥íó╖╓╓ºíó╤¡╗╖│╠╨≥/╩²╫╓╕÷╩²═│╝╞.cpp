#include<stdio.h>
int main(void)
{
	int n,i,a,b,c,d,f;
	a=b=c=d=f=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		if(i%2==1)
		a++;
		else if (i%2==0)
		b++;
		if(i%3==0)
		c++;
		if(i%5==0)
		d++;
		if(i%7==0)
		f++;
	}
	printf("%d %d %d %d %d",a,b,c,d,f);
	return 0;
}
