#include<stdio.h>
int main(void)
{
	float hero;
	scanf("%f",&hero);
	printf("%.1f\n%.1e",hero,hero);
	return 0;
 } 
