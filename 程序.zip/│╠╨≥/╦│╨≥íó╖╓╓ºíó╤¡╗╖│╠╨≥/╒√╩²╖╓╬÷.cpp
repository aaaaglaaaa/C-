#include<stdio.h>
int main(void)
{
	long int num,n,n1,n2,n3,lnum,nnum,i;
	scanf("%ld",&num);
	i=1;
	nnum=num/10;
	lnum=nnum;
	n=num%10;
	n1=n;
	while(lnum%10!=0||lnum/10!=0)
	{
		n2=lnum%10;
		lnum/=10;
		if(n1>=n2);
		else if(n1<n2)
		n1=n2;
		i++;
		
	}
	while(nnum%10!=0||lnum/10!=0)
	{
		n3=nnum%10;
		nnum/=10;
		if(n<=n3);
		else if(n>n3)
		 n=n3;
	}
	printf("%d %ld %ld",i,n1,n);
	return 0;
 } 
