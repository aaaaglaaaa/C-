#include<stdio.h>
int he(int n)
{
	int sum=0;
	while(n!=0)
	{
		sum+=n%10;
		n=n/10;
	}
	return sum;
}
int main(void)
{
	long int a[1000],n,i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int best=a[0];
	for(i=1;i<n;i++)
	{
		if(he(best)<he(a[i]))
		best=a[i];
		if(he(best)==he(a[i]))
		best=best>a[i]?best:a[i]; 
	}
	printf("%d",best);
	return 0;
}
