#include<stdio.h>
int main(void)
{
	char c[1000]={'\0'};
	gets(c);
	int i=0,sum=0;
	while(c[i]!='\0')
	{
		sum+=c[i];
		i++;
	}
	printf("%d",sum&0xFF);
}
