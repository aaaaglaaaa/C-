#include<stdio.h>
int main(void)
{
	int n,i,j,min=0;
	int a[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(i!=j&&a[i]-a[j]>=0)
			{
				min=(a[i]-a[j])<min?(a[i]-a[j]):min;
			}
		}
	}
	printf("%d",min);
	return 0;
}
