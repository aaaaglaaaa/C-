#include<stdio.h>
int main(void)
{
	int a,b,c,d,m;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	a=a>b?a:b;
	a=a>c?a:c;
	a=a>d?a:d;
	printf("%d",a);
	return 0;
	
}
