#include<stdio.h>
int main(void)
{
	double S,A,fee,good;
	scanf("%lf",&S);
		A=S-3500;
	if(S<=3500)
	fee=0;
	else 
	{
		if(A<=1500)
		fee=A*0.03;
		else if(A>1500&&A<=4500)
		fee=1500*0.03+(A-1500)*0.1;
		else if(A>4500&&A<=9000)
		fee=1500*0.03+3000*0.1+(A-4500)*0.2;
		else if(A>9000&&A<=35000)
		fee=1500*0.03+3000*0.1+4500*0.2+(A-9000)*0.25;
		else if(A>30000)
		fee=1500*0.03+3000*0.1+4500*0.2+26000*0.25+(A-35000)*0.3;
	}
	good=S-fee;
	printf("%.0lf",good);
	return 0;
 } 
