#include<stdio.h>
int main(void)
{
	int n,i;
	scanf("%d",&n);
	i=0;
	while(n!=1)
	{
		if(n%2==0)
		n/=2;
		else
		n=3*n+1;
		i++;
	}
	printf("%d",i);
	return 0; 
}
