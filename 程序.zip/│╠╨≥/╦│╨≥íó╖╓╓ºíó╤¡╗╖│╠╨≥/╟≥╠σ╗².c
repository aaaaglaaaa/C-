#include<stdio.h> 
#define PI 3.1415926

float mass(float density,float d)

{

return density * PI * d *d*d/6;

}

int main(void)

{
int m,n;
scanf("%d",&m);
scanf("%d",&n);
printf("%.3f %.3f", mass(7.86, m)/1000, mass(19.3, n)/1000);
return 0;
}
