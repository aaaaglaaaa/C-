#include<stdio.h>
float jie(float n);
int main(void)
{
	
	float M,N,m1,n1,l1;
	scanf("%f",&M);
	scanf("%f",&N);
	
	
	m1=jie(M)/(jie(N)*jie(M-N));
	printf("%.2f",m1);
	return 0;
	
}
float jie(float n)
	{
		float r;
		if(n==0||n==1)
		return 1;
		return n*jie(n-1);
	}
