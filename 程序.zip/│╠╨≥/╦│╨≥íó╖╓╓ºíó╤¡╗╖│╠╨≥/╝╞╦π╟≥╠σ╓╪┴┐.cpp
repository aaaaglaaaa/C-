#include<stdio.h>
double Ag(double v)
{
	double m;
	m=19.3*v;
	return m;
}
double Fe(double v)
{
	double m;
	m=7.86*v;
	return m;
}
int main()
{
	double d1,d2,v1,v2;
	scanf("%lf %lf",&d1,&d2);
	v1=3.1415926*d1*d1*d1/6000;
	v2=3.1415926*d2*d2*d2/6000;
	printf("%.3lf %.3lf\n",Fe(v1),Ag(v2));
	return 0;
} 
