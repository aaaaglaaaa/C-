#include<stdio.h>
int main(void)
{
	int num,i,j;
	scanf("%d",&num);
	for(i=1;i<num*num*num;i+=2)
	{
		if(num*i==num*num*num-((num-1)*num))
		break;
	 } 
	 for(j=0;j<num;j++)
	 {printf("%d ",i);
	 i=i+2;
	 }
	 return 0;
	
}
