#include<stdio.h>
int main(void)
{
	int gj,mj,xj;
	gj=mj=xj=0;
	while(gj<20)
	{	gj++;  
	    mj=0;
		while(mj<34)
		{
				mj++;  
				xj=0;
			while(xj<99)
			{	xj++;
				if(15*gj+ 9*mj+xj == 300&&gj+mj+xj== 100)
				printf("%d %d %d\n",gj,mj,xj);
			}
		}
	}
	return 0;
}
