#include<stdio.h>
int main(void)
{
	float p,m,l;
	char ch='A';
	scanf("%f",&p);
	if(p>0&&p<=110)
	{m=0.5*p;
	l=0;
	}
	else if(p>110&&p<=210)
	{
		m=0.5*110+0.55*(p-110);
		l=p-110;
		ch++; 
	}
	else if(p>210)
	{
		l=p-210;
		m=0.5*110+0.55*(210-110)+l*0.7;
		ch+=2;
	}
	printf("%.2f %c %.2f",m,ch,l);
	return 0;
 } 
