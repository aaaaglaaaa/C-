#include<stdio.h>
int main(void)
{
	int r,w,b;
	for(r=0;r<=3;r++)
	{
		for(w=0;w<=4;w++)
		{
			for(b=0;b<=5;b++)
			{
				if(r+w+b==8)
				printf("%d %d %d\n",r,w,b);
				else;
			}
		}
	}
	return 0;
}
