#include<stdio.h>
int main(void)
{
	int n;
	int m=0;
	int i=4;
	int a,b,c;
	scanf("%d",&n);
	scanf("%d %d %d",&a,&b,&c);
	while(i<=n)
	{
		if((b>a&&b>c)||(b<a&&b<c))
		   m=m+1;
		else;
		a=b;
		b=c;
		scanf("%d",&c);
		i++; 
		
	}
	if((b>a&&b>c)||(b<a&&b<c))
		   m=m+1;
	printf("%d",m);
	return 0;
 } 
 
