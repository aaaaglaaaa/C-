#include<stdio.h>
int main(void)
{
	int num;
	int score=0;
	int i=2;
	scanf("%d",&num);
	while(num!=0)
	{
		if(num==1){
		score++;
		i=2;
			scanf("%d",&num);
		}
		
		else if(num==2)
{
		score=score+i;
		i=i+2;
			scanf("%d",&num);
	}

}
printf("%d",score); 
return 0;} 
