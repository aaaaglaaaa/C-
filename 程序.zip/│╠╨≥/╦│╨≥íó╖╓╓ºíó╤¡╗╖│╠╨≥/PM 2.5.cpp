#include<stdio.h>
int main(void)
{
	int n,a,b,c,d,e,f;
	float data; 
	float sum;
	int i=0;
	a=b=c=d=e=f=0;
	scanf("%d",&n);
	while(i<n)
	{	scanf("%f",&data);
		if(data>=0&&data<=50)
		a++;
		else if(data>=51&&data<=100)
		b++;
		else if(data>=101&&data<=150)
		c++;
		else if(data>=151&&data<=200)
		d++;
		else if(data>=201&&data<=300)
		e++;
		else if(data>300)
		f++;
		i=i+1;
		sum=sum+data;
	
	}
	printf("%.2f\n",sum/n);
	printf("%d %d %d %d %d %d",a,b,c,d,e,f);
	return 0;
}
