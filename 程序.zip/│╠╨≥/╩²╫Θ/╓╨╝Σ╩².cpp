#include<stdio.h>
int main(void)
{
	int a[1000];
	int i,n,j;
	int fu=-1;
	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("%d",&a[i]);
	int c,b;
	for(i=0;i<n;i++)
	{
		for(j=0,c=0,b=0;j<n;j++)
		{
			if(a[j]!=a[i])
			{
			if(a[i]<a[j]) c++;
			if(a[i]>=a[j]) b++;}
			else;
		}
		if(c==b)
		fu=a[i];
	}
	printf("%d",fu);
	return 0;
}
