#include<stdio.h>
#include<string.h>
int main (void)
{

char str[80];
int i,j=0;
gets(str);
for(i=0;i<strlen(str);i++)
{
	if(str[i]>='a'&&str[i]<='z') 
	str[i]=str[i]-32;}
	 
for(i=0;i<strlen(str);i++)
{
	if(str[i]>='A'&&str[i]<='Z')
	{
		for(j=i+1;j<strlen(str);j++)
		{
			if(str[j]>='A'&&str[j]<='Z')
			{
				int t;
				if(str[j]<str[i])
				{
					t=str[i];
					str[i]=str[j];
					str[j]=t;
				}
			}
		}
	 } 
}
for(i=0;i<strlen(str);i++)
printf("%c",str[i]);
return 0;
}
