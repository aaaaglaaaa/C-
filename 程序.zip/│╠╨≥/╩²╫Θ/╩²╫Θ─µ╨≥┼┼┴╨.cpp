#include<stdio.h>
int main(void)
{
	int z,b,c,d,e;
	scanf("%d,%d,%d,%d,%d",&z,&b,&c,&d,&e);
	int a[5];
	a[0]=z;
	a[1]=b;
	a[2]=c;
	a[3]=d;
	a[4]=e;
	for(int i=4;i>=0;i--)
	printf("%d ",a[i]);
	 } 
