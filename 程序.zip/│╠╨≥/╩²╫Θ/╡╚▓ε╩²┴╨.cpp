#include<stdio.h>
void select_sort(int a[],int n)
{   int temp; 
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
			
		}
	}
	
int main(void)
{

int n,i;
scanf("%d",&n);
int a[n];
int d;
for(i=0;i<n;i++)
scanf("%d",&a[i]);
select_sort(a,n);
int c=a[1]-a[0];
for(i=1;i<n-1;i++)
{
	if(a[i+1]-a[i]==c)
	d=1;
	else{
		d=0;
		break;
	}
}
if(d==1)printf("%d",c);
else printf("no");
return 0; }
