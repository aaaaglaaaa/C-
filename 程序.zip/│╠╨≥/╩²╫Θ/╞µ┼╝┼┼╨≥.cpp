#include<stdio.h>
int main(void)
{void select_sort(int a[],int n);
int a[1000];
int b[100];
int c[100];
int n;
int m=0,q=0;
scanf("%d",&n);
for(int i=0;i<n;i++)
scanf("%d",&a[i]);
for(int j=0;j<n;j++)
{
	if(a[j]%2==0)
	{   int temp=a[j];
		b[m]=temp;
		m++;
	}
	else
	{int lin=a[j];
		c[q]=lin;
		q++;
	}
}
	select_sort(b,m);
	select_sort(c,q);

    for(int x=0;x<q;x++)
    printf("%d ",c[x]);
    printf("  ");\
    for(int y=0;y<m;y++)
	printf("%d ",b[y]);
    return 0;


	
}
void select_sort(int a[],int n)
{   int temp; 
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
			
		}
	}
	
