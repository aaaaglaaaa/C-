#include<stdio.h>
int main(void)
{
  int i,arr[10]; 
  int brr[10];  
  for(i=0;i<10;i++)
     scanf("%d",&arr[i]);
  for(i=1;i<10;i++)
     brr[i]=arr[i]/arr[i-1];   
  for(i=1;i<10;i++)
  { 
    printf("%d ",brr[i]);
    
   }
}
