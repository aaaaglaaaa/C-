#include<stdio.h>
void select(int a[],int n)
{   int temp; 
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
			
		}
	}
	void sort(int* n, int m) {
	int t, i, j;
	for (i = 1; i < m; i++) {
		for (j = 0; j < m - i; j++) {
			if (n[j] > n[j + 1]) {
				t = n[j];
				n[j] = n[j + 1];
				n[j + 1] = t;
			}
		}
	}
}
int main(void)
{
	int n,m,t,k;
	int i,j,sum;
	int a[20][20];
	int b[50];
	int x=0;
	scanf("%d",&n);
	scanf("%d",&m);
	scanf("%d",&t);
	scanf("%d",&k);
	
	for(i=0;i<n;i++){ 
	for(j=0;j<m;j++) scanf("%d",&a[i][j]);}
	for(i=0;i<n;i++)
{
		for(j=0;j<m;j++)
	{ if(a[i][j]==k)
	{
		if(j+1<m&&a[i][j+1]!=a[i][j]) b[x++]=a[i][j+1];
		if(j-1>=0&&a[i][j-1]!=a[i][j]) b[x++]=a[i][j-1];
		if(i+1<n&&a[i+1][j]!=a[i][j]) b[x++]=a[i+1][j];
		if(i-1>=0&&a[i-1][j]!=a[i][j]) b[x++]=a[i-1][j];
	}
	}
	} 
	select(b,x);
	for(i=1,sum=1;i<x;i++)
	{
		if(b[i]!=b[i-1])
		sum++; 
	}
	printf("%d",sum);
	return 0;
}
