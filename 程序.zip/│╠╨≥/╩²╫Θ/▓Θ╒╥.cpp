#include<stdio.h>
int main(void)
{
	int n,num;
	int b[100]={-1, };
	int k=0; 
	scanf("%d",&n);
	scanf("%d",&num);
	int a[100];
	for(int i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(int j=0;j<n;j++)
	{
		if(a[j]==num)
		{	b[k]=j;
		k++;
		}
		else;
	
	}
	if(b[0]==-1)
	printf("-1");
	else{
		for(int o=0;o<100;o++)
		{
			if (b[o]!=0)
			printf("%d ",b[o]);
		}
	}
	return 0;
}
