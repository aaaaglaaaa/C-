#include<stdio.h> 
int main(){
	int m,t;
	int i,j,total;
	scanf("%d",&m);
	int a[m][m];
	int b[40];
	for(i=0;i<m;i++){
		for(int j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++){
		int total=0;
		for(j=0;j<m;j++){
			total=total+a[i][j];
		}
		b[i]=total;
	}
	for(i=0;i<m;i++){
		total=0;
		for(j=0;j<m;j++){
			total=total+a[j][i];
	}
	b[i+m]=total;
    }
    total=0;
    for(i=0;i<m;i++){
    	total=total+a[i][i];
	}
	b[2*m]=total;
	total=0;
    for(i=0;i<m;i++){
    	total=total+a[i][m-1-i];
	}
	b[2*m+1]=total;
	for(i = 0;i < 2*m+1;i++){
		for(j = 0;j < 2*m+1- i;j++){
			if(b[j]<b[j+1]){
			t=b[j];
			b[j]=b[j+1];
			b[j+1]=t;	
			}
		}
	} 
	for(i = 0;i < 2*m+2;i++)       		
		printf("%d ",b[i]);
	printf("\n");
	return 0;
}
