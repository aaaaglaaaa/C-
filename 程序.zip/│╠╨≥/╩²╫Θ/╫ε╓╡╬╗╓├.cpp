#include<stdio.h>
int main(void)
{
	int n,max,m;
	scanf("%d",&n);
	int a[81];
	for(int i=0;i<n;i++)
    scanf("%d",&a[i]);
    max=a[0];
    m=0;
    for(int j=1;j<n;j++)
    {
    	if(max<a[j])
    	{
    		max=a[j];
    		m=j;
		}
		else;
	}
	printf("%d %d %d",n,max,m);
	return 0;
}
