#include <stdio.h>
int main()
{
    char p[20];
    gets(p);
    for (int i=0; i<20; i++){
        if (p[i]>='A' && p[i]<='Z')
            switch(p[i]){
            case 'A': p[i]='Z'; break;
            case 'B': p[i]='Y'; break;
            case 'C': p[i]='X'; break;
            case 'D': p[i]='W'; break;
            case 'E': p[i]='V'; break;
            case 'F': p[i]='U'; break;
            case 'G': p[i]='T'; break;
            case 'H': p[i]='S'; break;
            case 'I': p[i]='R'; break;
            case 'J': p[i]='Q'; break;
            case 'K': p[i]='P'; break;
            case 'L': p[i]='O'; break;
            case 'M': p[i]='N'; break;
            case 'N': p[i]='M'; break;
            case 'O': p[i]='L'; break;
            case 'P': p[i]='K'; break;
            case 'Q': p[i]='J'; break;
            case 'R': p[i]='I'; break;
            case 'S': p[i]='H'; break;
            case 'T': p[i]='G'; break;
            case 'U': p[i]='F'; break;
            case 'V': p[i]='E'; break;
            case 'W': p[i]='D'; break;
            case 'X': p[i]='C'; break;
            case 'Y': p[i]='B'; break;
            case 'Z': p[i]='A'; break;
            default: break;
            }
        else if (p[i]>='a' && p[i]<='z')
            switch(p[i]){
            case 'a': p[i]='z'; break;
            case 'b': p[i]='y'; break;
            case 'c': p[i]='x'; break;
            case 'd': p[i]='w'; break;
            case 'e': p[i]='v'; break;
            case 'f': p[i]='u'; break;
            case 'g': p[i]='t'; break;
            case 'h': p[i]='s'; break;
            case 'i': p[i]='r'; break;
            case 'j': p[i]='q'; break;
            case 'k': p[i]='p'; break;
            case 'l': p[i]='o'; break;
            case 'm': p[i]='n'; break;
            case 'n': p[i]='m'; break;
            case 'o': p[i]='l'; break;
            case 'p': p[i]='k'; break;
            case 'q': p[i]='j'; break;
            case 'r': p[i]='i'; break;
            case 's': p[i]='h'; break;
            case 't': p[i]='g'; break;
            case 'u': p[i]='f'; break;
            case 'v': p[i]='e'; break;
            case 'w': p[i]='d'; break;
            case 'x': p[i]='c'; break;
            case 'y': p[i]='b'; break;
            case 'z': p[i]='a'; break;
            default: break;
            }
    }
    //���ԭ��
    puts(p);
    return 0;
}
