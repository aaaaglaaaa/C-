#include<stdio.h>
int main(void)
{
	int n,m;
	int i,j,k=0,l=0;
	scanf("%d",&n);
	scanf("%d",&m);
	int a[n][m];
	int c[n*m];
	int b[m][n];
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=n-1;j>=0;j--)
		{
			c[k]=a[j][i];
			k++;
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			b[i][j]=c[l];
			l++;
		}
	}
		for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n") ;
	}
}
