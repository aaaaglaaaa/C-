#include<stdio.h>
int main(void)
{
	int shuhe(int n);
	int shuwei(int n);
	int n,i,sum,j=0;
	int wo;
	int x;
	scanf("%d",&n);
	int num=n;
	i=shuwei(n);
	sum=shuhe(n);
	int a[i];
	while(num!=0)
	{
		x=num%10;
		a[j]=x;
		num=num/10;
		j++;
	}
	for(j=0;j<i;j++)
	{
		if(a[j]==a[i-j-1])
		wo=1;
		else{wo=0;
		break;
		}
	}
	if(wo==1) 
	printf("%d",sum);
	else
	printf("no");
	return 0;

	
}
int shuhe(int n)
{
	int a=n;
	int x,i=0,sum;
	while(a!=0)
	{
		x=a%10;
		sum+=x;
		a=a/10;
		i++;
	}
	return sum;
}
int shuwei(int n)
{
	int a=n;
	int x,i=0,sum;
	while(a!=0)
	{
		x=a%10;
		sum+=x;
		a=a/10;
		i++;
	}
	return i;
}
