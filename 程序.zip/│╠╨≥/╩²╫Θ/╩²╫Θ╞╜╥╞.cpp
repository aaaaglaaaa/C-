#include<stdio.h>
int main(void)
{
	int a[10]={1,2,3,4,5,6,7,8,9,10};
	int b[10];
	int n;
	scanf("%d",&n);
	for(int i=9-n,j=0;i<10;i++,j++)
	{
		b[i]=a[j];
	}
	for(int x=0,y=1+n;x<9-n;x++,y++)
	{
		b[x]=a[y];
	}
	for(int z=0;z<10;z++)
	printf("%d ",b[z]);
	return 0;
}
