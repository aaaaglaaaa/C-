#include <stdio.h>
int main()
{
	int n,m;
	int i,j;
	int a[105][105],b[105][105];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)  
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
			b[i][j]=1;
		}
	}
	for(i=0;i<n;i++)  //�ҳ���������������ͬ��ɫ�� 
	{
		for(j=0;j<m-2;j++)
		{
			if(a[i][j]==a[i][j+1] && a[i][j+1]==a[i][j+2])
			{
				b[i][j]=0;     //�ҵ����� 
				b[i][j+1]=0;
				b[i][j+2]=0;
			}
		}
	}
	for(i=0;i<m;i++)  
	{
		for(j=0;j<n-2;j++)
		{
			if(a[j][i]==a[j+1][i] && a[j+1][i]==a[j+2][i])
			{
				b[j][i]=0;     //�ҵ����� 
				b[j+1][i]=0;
				b[j+2][i]=0;
			}
		}
	}
	printf("\n");
	for(i=0;i<n;i++)  //��� 
	{
		for(j=0;j<m;j++)
		{
			if(b[i][j]==0)
			{
				printf("%d ",b[i][j]);
				continue;
			}
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
 } 
