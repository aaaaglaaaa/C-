#include<stdio.h>
#include<string.h>
int main(void)
{
	char s[50];
	int i,j;
	int a=0,b=0,c=0;
	gets(s);
	for(i=0;i<strlen(s);i++)
	{
		if(s[i]=='(')
		{
		for (j=i+1;j<strlen(s);j--)
		{
			if (s[j]==')')
			{
				a=1;
				break;
			}
			else a=2;
			
			
		}
	    }
	    	if(s[i]=='[')
		{
		for (j=i+1;j<strlen(s);j++)
		{
			if( s[j]==']')
			{
				b=1;
				break;
			}
			else b=2;
	    }
	}    
	    	if(s[i]=='{')
		{
		for (j=i+1;j<strlen(s);j++)
		{
			if (s[j]=='}')
			{
				c=1;
				break;
			}
			else
			{
				c=2;
		}
	    }
		
	}
	
}if((a==1&&b==1&&c==1)||(a==0&&b==0&&c==1)||(a==1&&b==0&&c==0)||(a==0&&b==1&&c==0)||(a==1&&b==1&&c==0)||(a==0&&b==1&&c==1)||(a==1&&b==0&&c==1)||(a==0&&b==0&c==0))
	printf("yes");
	else printf("no");
	return 0;}
