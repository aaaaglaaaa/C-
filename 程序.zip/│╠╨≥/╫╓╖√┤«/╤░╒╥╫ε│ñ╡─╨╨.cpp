#include<stdio.h>
#include<string.h>
int main()
{
	char s[100], end[100];
	int len, max;
	gets(s);
	strcpy(end, s);
	max = strlen(s);
	while (strcmp(s, "***end***"))
	{
		gets(s);
		len = strlen(s);
		if (len > max)
		{
			max = len;
			strcpy(end, s);
		}
	}
	printf("%d\n", max);
	puts(end);
}
