#include<stdio.h>
#include<string.h>
int main(void)
{
	char c;
	int n;
	char a[100];
	scanf("%c",&c);
	scanf("%d\n",&n);
	gets(a);
	int x,y,sum=0;
	if(n==1)
{
	for(int i=0;i<100;i++)
	{
		if(a[i]==c) sum++;
	}
}
else if(n==0)
{
	if(c>='a'&&c<='z')
	{
		x=c;
		y=c-32;
	}
	else if(c>='A'&&c<='Z')
	{
		x=c;
		y=c+32;
	}
	for(int j=0;j<100;j++)
	{
		if(a[j]==x||a[j]==y) sum++;
	}
}
printf("%d",sum);
return 0;
	
	
}
