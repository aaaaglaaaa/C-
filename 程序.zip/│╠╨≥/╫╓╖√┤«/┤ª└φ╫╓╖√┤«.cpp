#include<stdio.h>
#include<string.h>
void sort(char* str, int n)
{
	int i, j;
	char t;
	for (i = 1; i < n; i++)
	{
		for (j = 0; j < n - i; j++)
		{
			if (str[j] > str[j + 1])
			{
				t = str[j];
				str[j] = str[j + 1];
				str[j + 1] = t;
			}
		}
	}
}
int main(void)
{
	char c[100],left[100],right[100],end[100];
	gets(c);
	int i; 
	int t=c[0];
	int x=0,b=0,y=0;
	for(i=1;i<strlen(c);i++)
	{
		if(c[i]>t)
		{
			left[x++]=c[i];
		}
		else right[b++]=c[i];
	}
sort(right,b);
	for(i=0;i<x;i++)
	{
		end[y++]=left[i];
	}
	end[y++]=t;
	for(i=0;i<b;i++)
	end[y++]=right[i];
    end[y]='\0';
    puts(end);
	return 0;
}
