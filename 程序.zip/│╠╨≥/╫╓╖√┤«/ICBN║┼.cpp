#include<stdio.h>
int main(void)
{
	char a[14],b[12]="0123456789X";
	gets(a);
	int i,y=1,sum=0;
	for(i=0;i<11;i++)
	{if(a[i]=='-') continue;
	 sum+=(a[i]-'0')*y;
	 y++;
	}
	if(b[sum%11]==a[12])
	printf("RIGHT");
	else
	{
		a[12]=b[sum%11];
		puts(a);
	}
	return 0;
}
