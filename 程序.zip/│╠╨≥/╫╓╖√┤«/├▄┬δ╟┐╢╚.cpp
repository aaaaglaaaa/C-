#include<stdio.h>
#include<string.h>
int main()
{
	int Q=0,i,n1=0,n2=0,n3=0,n4=0,sum=0;
	char s[50];
	gets(s);
	if(strlen(s)==0)
	Q=0;
	else
	Q=1;	
	if(strlen(s)>8)
	Q=Q+1;
	for(i=0;i<strlen(s);i++)
	{
		if(s[i]>=97&&s[i]<=122)
		n1=1;
		else if(s[i]>=65&&s[i]<=90)
		n2=1;
		else if(s[i]>=48&&s[i]<=57)
		n3=1;
		else
		n4=1;
	}
	sum=n1+n2+n3+n4;
	if(sum==4) Q=Q+3;
	else if(sum==3) Q=Q+2;
	else if(sum==2) Q=Q+1;
	printf("%d",Q);
	return 0;
}
